public class ExtendedEucledian {

    int r;
    int r1;
    int r2;
    int s1;
    int s2;
    int s;
    int t1;
    int t2;
    int t;

    public ExtendedEucledian(int r1, int r2) {
        this.r1 = r1;
        this.r2 = r2;
        s1=1;
        s2=0;
        t1=0;
        t2=1;
    }

    public int getGCD(){
        int q = r2/r1;
        System.out.println("r1\tr2\tr\tq\ts1\ts2\ts\tt1\tt2\tt");
        while(r2!=0){
            r = r1%r2;
            s = s1-(q*s2);
            t = t1-(q*t2);
            System.out.println(r1+"\t"+r2+"\t"+r+"\t"+q+"\t"+s1+"\t"+s2+"\t"+s+"\t"+t1+"\t"+t2+"\t"+t);
            r1=r2;
            r2=r;
            s1=s2;
            s2=s;
            t1=t2;
            t2=t;
        }
        return r1;
    }

    public static void main(String[] args) {
        ExtendedEucledian ee = new ExtendedEucledian(6,8);
        System.out.println(ee.getGCD());
    }
}
