import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class SHA1 {

    private String message;

    public SHA1(String message) {
        this.message = message;
    }

    public byte[] getHash() throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA1");
        return md.digest(message.getBytes());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter the message : ");
        String message = sc.next();
        SHA1 algo = new SHA1(message);
        try {
            byte[] hash = algo.getHash();
            System.out.println("SHA-1 : "+byteArrayToHex(hash));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    private static String byteArrayToHex(byte[] hash) {
        char hexDigit[] = {'0', '1', '2', '3', '4', '5', '6', '7',
                '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        StringBuffer buf = new StringBuffer();
        for (int j=0; j<hash.length; j++) {
            buf.append(hexDigit[(hash[j] >> 4) & 0x0f]);
            buf.append(hexDigit[hash[j] & 0x0f]);
        }
        return buf.toString();

    }
}
